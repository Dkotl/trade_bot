from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas_ta as ta


class EmaCrossStrategy(IStrategy):
    leverage = 5.0
    order_types = {
        'entry': 'limit', 'exit': 'limit', 'emergency_exit': 'market',
        'force_entry': 'market', 'force_exit': 'market', 'stoploss': 'market',
        'stoploss_on_exchange': False, 'leverage': 'limit'
    }

    timeframe = '5m'

    # Слегка увеличим стоп и тейк под новое качество сигналов
    stoploss = -0.02
    minimal_roi = {
        "0": 0.04
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Быстрая и медленная скользящие
        dataframe['ema_fast'] = ta.ema(dataframe['close'], length=9)
        dataframe['ema_slow'] = ta.ema(dataframe['close'], length=21)

        # Глобальный тренд (EMA 200)
        dataframe['ema_trend'] = ta.ema(dataframe['close'], length=200)

        # Сила тренда (ADX). По умолчанию длина 14
        dataframe['adx'] = ta.adx(
            dataframe['high'], dataframe['low'], dataframe['close'])['ADX_14']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Фильтр: тренд сильный (ADX > 22)
        strong_trend = dataframe['adx'] > 22

        # LONG: Пересечение снизу вверх + цена выше глобальной EMA 200 + сильный тренд
        dataframe.loc[
            (dataframe['ema_fast'] > dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) <= dataframe['ema_slow'].shift(1)) &
            (dataframe['close'] > dataframe['ema_trend']) &
            strong_trend,
            'enter_long'
        ] = 1

        # SHORT: Пересечение сверху вниз + цена ниже глобальной EMA 200 + сильный тренд
        dataframe.loc[
            (dataframe['ema_fast'] < dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) >= dataframe['ema_slow'].shift(1)) &
            (dataframe['close'] < dataframe['ema_trend']) &
            strong_trend,
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0

        # Быстрый выход, если тренд развернулся против нас
        dataframe.loc[
            (dataframe['ema_fast'] < dataframe['ema_slow']),
            'exit_long'
        ] = 1

        dataframe.loc[
            (dataframe['ema_fast'] > dataframe['ema_slow']),
            'exit_short'
        ] = 1

        return dataframe
