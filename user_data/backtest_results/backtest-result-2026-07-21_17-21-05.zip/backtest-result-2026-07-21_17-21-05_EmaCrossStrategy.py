from freqtrade.strategy import IStrategy
from pandas import DataFrame
import pandas_ta as ta


class EmaCrossStrategy(IStrategy):
    # Настройки кредитного плеча и ордеров для фьючерсов
    leverage = 5.0
    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'emergency_exit': 'market',
        'force_entry': 'market',
        'force_exit': 'market',
        'stoploss': 'market',
        'stoploss_on_exchange': False,
        'leverage': 'limit'
    }

    # Основные параметры торговли
    timeframe = '5m'

    # Жесткий стоп-лосс (1.5%) и тейк-профит (3%) для быстрого таймфрейма
    stoploss = -0.015
    minimal_roi = {
        "0": 0.03
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Расчет быстрой и медленной экспоненциальных скользящих средних
        dataframe['ema_fast'] = ta.ema(dataframe['close'], length=9)
        dataframe['ema_slow'] = ta.ema(dataframe['close'], length=21)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Инициализируем колонки сигналов
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        # Сигнал в LONG: Быстрая EMA пересекает Медленную СНИЗУ ВВЕРХ
        dataframe.loc[
            (dataframe['ema_fast'] > dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) <= dataframe['ema_slow'].shift(1)),
            'enter_long'
        ] = 1

        # Сигнал в SHORT: Быстрая EMA пересекает Медленную СВЕРХУ ВНИЗ
        dataframe.loc[
            (dataframe['ema_fast'] < dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) >= dataframe['ema_slow'].shift(1)),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Инициализируем колонки выхода
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0

        # Досрочный выход из LONG, если пошел обратный сигнал пересечения
        dataframe.loc[
            (dataframe['ema_fast'] < dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) >= dataframe['ema_slow'].shift(1)),
            'exit_long'
        ] = 1

        # Досрочный выход из SHORT, если пошел обратный сигнал пересечения
        dataframe.loc[
            (dataframe['ema_fast'] > dataframe['ema_slow']) &
            (dataframe['ema_fast'].shift(1) <= dataframe['ema_slow'].shift(1)),
            'exit_short'
        ] = 1

        return dataframe
